#!/bin/bash


./startTrace.sh -m SpeedOfVectorVsArrayList -s ../../test/java/com/master/core/thread/BtraceSpeedOfVectorVsArrayList.java