#!/bin/bash

./startServer.sh -f ../../main/java/com/master/core/thread/SpeedOfVectorVsArrayList.java