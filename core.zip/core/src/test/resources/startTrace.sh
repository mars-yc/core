#!/bin/bash

. ~/.profile
export JAVA_HOME=/c/2017/tools/jdk1.7.0_71
export BTRACE_HOME=/c/2017/tools/btrace

usage()
{
        cat << EOF
usage $0 option

compile the specified java file and invoke the main function if have

OPTION:
        -h      show usage
        -m      the instance of running java main class
        -s      the btrace script

EOF
}

while getopts hm:s:p: OPTION
do
        case $OPTION in
                h)
                        usage
                        exit 1
                        ;;
                m)
                        mainClass=$OPTARG
                        ;;
                s)
                        btraceScript=$OPTARG
                        ;;
                p)
                        port=$OPTARG
                        ;;
        esac
done

process()
{
        if [[ -z $mainClass ]]; then
                error You should at least know which class you wanna trace.
                exit 1
        fi
        if [[ -z $btraceScript ]]; then
                error The btrace script is not specified.
                exit 1
        fi

        pid=`jps | grep $mainClass | awk '{print $1}'`
        
#         if [[ ""$pid = "" ]]; then
#                 echo $mainClass is not running.
#                 exit 1
#         fi

		while [[ ""$pid = "" ]]
		do
                echo $mainClass is not running.
                pid=`jps | grep $mainClass | awk '{print $1}'`
                sleep 0.01
        done

        command="btrace"

        if [[ ! -z $port ]]; then
                command=${command}" -p $port"
        fi

        command=${command}" $pid $btraceScript"

        exeWithTimestampLog $command
}

process
