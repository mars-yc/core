package com.master.core.thread;

import static com.sun.btrace.BTraceUtils.println;
import static com.sun.btrace.BTraceUtils.str;
import static com.sun.btrace.BTraceUtils.strcat;
import static com.sun.btrace.BTraceUtils.timestamp;

import com.sun.btrace.AnyType;
import com.sun.btrace.annotations.BTrace;
import com.sun.btrace.annotations.Kind;
import com.sun.btrace.annotations.Location;
import com.sun.btrace.annotations.OnMethod;

@BTrace
public class BtraceSpeedOfVectorVsArrayList {

    @OnMethod(
            clazz = "java.util.Arrays",
            method = "copyOf",
            location = @Location(Kind.RETURN)
    )
	public static void traceArraysCopyOf2(AnyType[] args) {
		println("===Arrays.copyOf get invoked=== ");
		println(timestamp());
	}
    
//    @OnMethod(
//            clazz = "java.util.Arrays",
//            method = "copyOf",
//            location = @Location(Kind.RETURN)
//    )
//	public static void traceArraysCopyOf2(AnyType arrays, int newCapacity) {
//		println("===Arrays.copyOf get invoked=== ");
//		println(strcat("new capacity is:",str(newCapacity)));
//		println(timestamp());
//	}
	
}